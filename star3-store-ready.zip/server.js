const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const express = require("express");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA = path.join(__dirname, "data.json");
const sessions = new Map();

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function load() {
  if (!fs.existsSync(DATA)) {
    const seed = {
      users: [],
      products: [
        {id:"p1",name:"بطاقة رقمية 10$",category:"بطاقات رقمية",price:10,stock:20,description:"بطاقة رقمية فورية.",codePrefix:"STAR10"},
        {id:"p2",name:"بطاقة رقمية 25$",category:"بطاقات رقمية",price:25,stock:15,description:"بطاقة رقمية فورية.",codePrefix:"STAR25"},
        {id:"p3",name:"بطاقة رقمية 50$",category:"بطاقات رقمية",price:50,stock:10,description:"بطاقة رقمية فورية.",codePrefix:"STAR50"}
      ],
      topups: [],
      orders: []
    };
    save(seed);
  }
  return JSON.parse(fs.readFileSync(DATA, "utf8"));
}
function save(db){ fs.writeFileSync(DATA, JSON.stringify(db,null,2)); }
function id(prefix="id"){ return prefix+"_"+crypto.randomBytes(6).toString("hex"); }
function hash(p){ return crypto.createHash("sha256").update(String(p)).digest("hex"); }

function getUser(req) {
  const token = req.headers.authorization?.replace("Bearer ","");
  const uid = token && sessions.get(token);
  if (!uid) return null;
  const db=load();
  return db.users.find(u=>u.id===uid) || null;
}
function admin(req){
  const u=getUser(req);
  return u && u.role==="admin" ? u : null;
}
function publicUser(u){
  return {id:u.id,email:u.email,name:u.name,balance:u.balance,role:u.role,createdAt:u.createdAt};
}
function ok(res,data){ res.json({ok:true,...data}); }
function fail(res,status,msg){ res.status(status).json({ok:false,error:msg}); }

app.post("/api/register",(req,res)=>{
  const {email,password,name=""}=req.body||{};
  if(!email||!password||password.length<6) return fail(res,400,"أدخل بريدًا صحيحًا وكلمة مرور من 6 أحرف على الأقل.");
  const db=load();
  if(db.users.some(u=>u.email.toLowerCase()===email.toLowerCase())) return fail(res,409,"البريد مستخدم بالفعل.");
  const u={id:id("u"),email:email.toLowerCase(),password:hash(password),name:name.trim()||"عميل",balance:0,role:"user",createdAt:new Date().toISOString()};
  db.users.push(u); save(db);
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,u.id);
  ok(res,{token,user:publicUser(u)});
});

app.post("/api/login",(req,res)=>{
  const {email,password}=req.body||{}, db=load();
  let u=db.users.find(x=>x.email===String(email||"").toLowerCase() && x.password===hash(password||""));
  if(!u && email===process.env.ADMIN_EMAIL && password===process.env.ADMIN_PASSWORD){
    u=db.users.find(x=>x.email===String(email).toLowerCase());
    if(!u){ u={id:id("u"),email:String(email).toLowerCase(),password:hash(password),name:"Administrator",balance:0,role:"admin",createdAt:new Date().toISOString()}; db.users.push(u); save(db); }
  }
  if(!u) return fail(res,401,"بيانات الدخول غير صحيحة.");
  const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,u.id);
  ok(res,{token,user:publicUser(u)});
});

app.post("/api/logout",(req,res)=>{
  const token=req.headers.authorization?.replace("Bearer ",""); if(token) sessions.delete(token); ok(res,{});
});

app.get("/api/me",(req,res)=>{
  const u=getUser(req); if(!u) return fail(res,401,"غير مسجل الدخول.");
  ok(res,{user:publicUser(u)});
});

app.get("/api/products",(req,res)=>{
  const db=load(); ok(res,{products:db.products.map(p=>({...p}))});
});

app.get("/api/orders",(req,res)=>{
  const u=getUser(req); if(!u) return fail(res,401,"سجل الدخول أولًا.");
  const db=load(); ok(res,{orders:db.orders.filter(o=>o.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});
});

app.post("/api/orders",(req,res)=>{
  const u=getUser(req); if(!u) return fail(res,401,"سجل الدخول أولًا.");
  const {productId}=req.body||{}, db=load(), p=db.products.find(x=>x.id===productId);
  if(!p) return fail(res,404,"المنتج غير موجود.");
  if(p.stock<=0) return fail(res,400,"المنتج غير متوفر.");
  if(u.balance<p.price) return fail(res,400,"الرصيد غير كافٍ. اشحن محفظتك أولًا.");
  const dbUser=db.users.find(x=>x.id===u.id);
  dbUser.balance-=p.price; p.stock-=1;
  const code=p.codePrefix+"-"+crypto.randomBytes(5).toString("hex").toUpperCase();
  const order={id:id("ord"),userId:u.id,productId:p.id,productName:p.name,amount:p.price,status:"completed",code,createdAt:new Date().toISOString()};
  db.orders.push(order); save(db);
  ok(res,{order,balance:dbUser.balance});
});

app.get("/api/topups",(req,res)=>{
  const u=getUser(req); if(!u) return fail(res,401,"سجل الدخول أولًا.");
  const db=load();
  const rows=db.topups.filter(t=>t.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  ok(res,{topups:rows});
});

app.post("/api/topups",(req,res)=>{
  const u=getUser(req); if(!u) return fail(res,401,"سجل الدخول أولًا.");
  const {amount,method="manual",reference=""}=req.body||{};
  const n=Number(amount);
  if(!Number.isFinite(n)||n<=0||n>10000) return fail(res,400,"مبلغ الشحن غير صالح.");
  const db=load();
  const t={id:id("top"),userId:u.id,amount:n,method,reference:String(reference).slice(0,200),status:"pending",createdAt:new Date().toISOString()};
  db.topups.push(t); save(db);
  ok(res,{topup:t,message:"تم إنشاء طلب الشحن، وسيظهر الرصيد بعد اعتماد العملية."});
});

app.get("/api/admin/overview",(req,res)=>{
  if(!admin(req)) return fail(res,403,"صلاحيات المدير مطلوبة.");
  const db=load();
  ok(res,{stats:{
    users:db.users.length,
    products:db.products.length,
    pendingTopups:db.topups.filter(t=>t.status==="pending").length,
    orders:db.orders.length,
    sales:db.orders.reduce((s,o)=>s+o.amount,0)
  },topups:db.topups.map(t=>({...t,user:db.users.find(u=>u.id===t.userId)?.email||"—"})).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),
  users:db.users.map(publicUser),
  products:db.products,
  orders:db.orders.sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});
});

app.post("/api/admin/topups/:id",(req,res)=>{
  if(!admin(req)) return fail(res,403,"صلاحيات المدير مطلوبة.");
  const {status}=req.body||{}, db=load(), t=db.topups.find(x=>x.id===req.params.id);
  if(!t) return fail(res,404,"طلب الشحن غير موجود.");
  if(!["approved","rejected"].includes(status)) return fail(res,400,"حالة غير صالحة.");
  if(t.status!=="pending") return fail(res,400,"تمت معالجة الطلب سابقًا.");
  t.status=status;
  if(status==="approved"){
    const u=db.users.find(x=>x.id===t.userId);
    if(u) u.balance+=t.amount;
  }
  t.processedAt=new Date().toISOString(); save(db); ok(res,{topup:t});
});

app.post("/api/admin/products",(req,res)=>{
  if(!admin(req)) return fail(res,403,"صلاحيات المدير مطلوبة.");
  const {name,category="بطاقات رقمية",price,stock=0,description="",codePrefix="CARD"}=req.body||{}, n=Number(price), s=Number(stock);
  if(!name||!Number.isFinite(n)||n<=0||s<0) return fail(res,400,"بيانات المنتج غير صحيحة.");
  const db=load(), p={id:id("p"),name,category,price:n,stock:s,description,codePrefix};
  db.products.push(p); save(db); ok(res,{product:p});
});

app.delete("/api/admin/products/:id",(req,res)=>{
  if(!admin(req)) return fail(res,403,"صلاحيات المدير مطلوبة.");
  const db=load(); db.products=db.products.filter(p=>p.id!==req.params.id); save(db); ok(res,{});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Store running on http://localhost:${PORT}`));
