const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let token=localStorage.getItem("star_token"), me=null, products=[];

async function api(url,opts={}) {
  const headers={"Content-Type":"application/json",...(opts.headers||{})};
  if(token) headers.Authorization="Bearer "+token;
  const r=await fetch(url,{...opts,headers});
  const d=await r.json().catch(()=>({ok:false,error:"خطأ غير متوقع"}));
  if(!r.ok) throw new Error(d.error||"تعذر تنفيذ العملية");
  return d;
}
function money(n){return Number(n).toFixed(2)}
function status(s){const map={pending:"قيد المراجعة",approved:"تم الاعتماد",rejected:"مرفوض",completed:"مكتمل"};return `<span class="status ${s}">${map[s]||s}</span>`}
function modal(html){$("#modalBody").innerHTML=html;$("#modal").hidden=false}
$("#closeModal").onclick=()=>$("#modal").hidden=true;

function loginModal(){
 modal(`<h2>تسجيل الدخول</h2><input id="lemail" type="email" placeholder="البريد الإلكتروني"><input id="lpass" type="password" placeholder="كلمة المرور"><button id="doLogin" class="btn primary full">دخول</button><p>ليس لديك حساب؟ <a href="#" id="showRegister">إنشاء حساب</a></p>`);
 $("#doLogin").onclick=async()=>{try{const d=await api("/api/login",{method:"POST",body:JSON.stringify({email:$("#lemail").value,password:$("#lpass").value})});token=d.token;localStorage.setItem("star_token",token);$("#modal").hidden=true;await refresh()}catch(e){alert(e.message)}};
 $("#showRegister").onclick=e=>{e.preventDefault();registerModal()}
}
function registerModal(){
 modal(`<h2>إنشاء حساب</h2><input id="rname" placeholder="الاسم"><input id="remail" type="email" placeholder="البريد الإلكتروني"><input id="rpass" type="password" placeholder="كلمة المرور"><button id="doRegister" class="btn primary full">إنشاء الحساب</button>`);
 $("#doRegister").onclick=async()=>{try{const d=await api("/api/register",{method:"POST",body:JSON.stringify({name:$("#rname").value,email:$("#remail").value,password:$("#rpass").value})});token=d.token;localStorage.setItem("star_token",token);$("#modal").hidden=true;await refresh()}catch(e){alert(e.message)}};
}
$("#loginBtn").onclick=loginModal;
$("#logoutBtn").onclick=async()=>{await api("/api/logout",{method:"POST"}).catch(()=>{});token=null;localStorage.removeItem("star_token");await refresh()};

async function loadProducts(){
 const d=await api("/api/products");products=d.products;$("#productCount").textContent=`${products.length} منتجات`;
 $("#productsGrid").innerHTML=products.map(p=>`<article class="product"><div class="product-art"><b>${escapeHtml(p.category)}</b></div><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description||"بطاقة رقمية")}</p><div class="product-meta"><div><div class="price">${money(p.price)}</div><div class="stock">${p.stock>0?`متوفر (${p.stock})`:"غير متوفر"}</div></div><button class="btn primary buy" data-id="${p.id}" ${p.stock<=0?"disabled":""}>شراء</button></div></article>`).join("");
 $$(".buy").forEach(b=>b.onclick=()=>buy(b.dataset.id));
}
async function buy(id){
 if(!me){loginModal();return}
 const p=products.find(x=>x.id===id);
 if(!confirm(`شراء ${p.name} مقابل ${money(p.price)}؟`))return;
 try{const d=await api("/api/orders",{method:"POST",body:JSON.stringify({productId:id})});alert("تم الشراء بنجاح. الكود: "+d.order.code);await refresh()}catch(e){alert(e.message)}
}
async function loadTopups(){
 if(!me){$("#topupsList").innerHTML='<div class="row">سجل الدخول لعرض عمليات الشحن.</div>';return}
 const d=await api("/api/topups");$("#topupsList").innerHTML=d.topups.length?d.topups.map(t=>`<div class="row"><span>${money(t.amount)} • ${t.method}</span>${status(t.status)}</div>`).join(""):'<div class="row">لا توجد عمليات شحن.</div>';
}
async function loadOrders(){
 if(!me){$("#ordersList").innerHTML='<div class="panel">سجل الدخول لعرض طلباتك.</div>';return}
 const d=await api("/api/orders");$("#ordersList").innerHTML=d.orders.length?d.orders.map(o=>`<div class="order-card"><b>${escapeHtml(o.productName)}</b><span style="float:left">${money(o.amount)}</span><div>${status(o.status)} • ${new Date(o.createdAt).toLocaleString("ar")}</div><div class="code">${escapeHtml(o.code)}</div></div>`).join(""):'<div class="panel">لا توجد طلبات بعد.</div>';
}
$$(".amounts button").forEach(b=>b.onclick=()=>{$$("#.amounts button")?.forEach?.(()=>{});$$(".amounts button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#topAmount").value=b.dataset.amt});
$("#topupBtn").onclick=async()=>{if(!me){loginModal();return}const amount=Number($("#topAmount").value);if(!amount)return alert("أدخل مبلغ الشحن.");try{await api("/api/topups",{method:"POST",body:JSON.stringify({amount,method:$("#topMethod").value,reference:$("#topRef").value})});alert("تم إرسال طلب الشحن.");$("#topAmount").value="";$("#topRef").value="";await loadTopups()}catch(e){alert(e.message)}};

async function loadAdmin(){
 if(!me||me.role!=="admin"){ $("#admin").hidden=true; return }
 $("#admin").hidden=false;
 const d=await api("/api/admin/overview");
 $("#stats").innerHTML=[["المستخدمون",d.stats.users],["المنتجات",d.stats.products],["شحنات معلقة",d.stats.pendingTopups],["المبيعات",money(d.stats.sales)]].map(x=>`<div class="stat"><span>${x[0]}</span><strong>${x[1]}</strong></div>`).join("");
 $("#adminTopups").innerHTML=d.topups.length?d.topups.map(t=>`<div class="admin-item"><b>${money(t.amount)}</b> — ${escapeHtml(t.user)}<br>${status(t.status)} ${t.status==="pending"?`<button class="btn primary approve" data-id="${t.id}">اعتماد</button><button class="danger reject" data-id="${t.id}">رفض</button>`:""}</div>`).join(""):"لا توجد طلبات";
 $$(".approve").forEach(b=>b.onclick=()=>reviewTopup(b.dataset.id,"approved"));$$(".reject").forEach(b=>b.onclick=()=>reviewTopup(b.dataset.id,"rejected"));
 $("#adminProducts").innerHTML=d.products.map(p=>`<div class="admin-item"><b>${escapeHtml(p.name)}</b> — ${money(p.price)} — ${p.stock}<button class="danger del" data-id="${p.id}">حذف</button></div>`).join("");
 $$(".del").forEach(b=>b.onclick=async()=>{if(confirm("حذف المنتج؟")){await api("/api/admin/products/"+b.dataset.id,{method:"DELETE"});await loadAdmin();await loadProducts()}});
}
async function reviewTopup(id,statusValue){try{await api("/api/admin/topups/"+id,{method:"POST",body:JSON.stringify({status:statusValue})});await refresh()}catch(e){alert(e.message)}}
$("#addProduct").onclick=async()=>{try{await api("/api/admin/products",{method:"POST",body:JSON.stringify({name:$("#newName").value,category:$("#newCategory").value,price:Number($("#newPrice").value),stock:Number($("#newStock").value),codePrefix:$("#newPrefix").value,description:$("#newDesc").value})});["newName","newPrice","newStock","newDesc"].forEach(x=>$("#"+x).value="");await loadAdmin();await loadProducts()}catch(e){alert(e.message)}};

function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function refresh(){
 try{const d=await api("/api/me");me=d.user}catch(e){me=null}
 $("#loginBtn").hidden=!!me;$("#logoutBtn").hidden=!me;$("#adminLink").hidden=!(me&&me.role==="admin");$("#balancePill").textContent=me?`الرصيد: ${money(me.balance)}`:"الرصيد: 0";
 await loadProducts();await loadTopups();await loadOrders();await loadAdmin();
}
refresh();
